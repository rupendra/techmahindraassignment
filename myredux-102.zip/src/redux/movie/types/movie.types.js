const ADD_MOVIE ="ADD_MOVIE";

export default ADD_MOVIE;