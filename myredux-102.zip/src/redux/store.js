import {createStore} from "redux";
import heroReducer from "./hero/reducers/hero.reducers";
import movieReducer from "./movie/reducers/movie.reducer";
import { combineReducers } from 'redux'
const store = createStore(combineReducers(
    {
        heroReducer,
        movieReducer
     }));




export default store;